﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tictactoehomework
{
    public partial class Form1 : Form
    {
        bool turn=true;
        int turncount = 1;
        
        
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        public void resetgame()
        {
            button1.Text = null;
            button2.Text = null;
            button3.Text = null;
            button4.Text = null;
            button5.Text = null;
            button6.Text = null;
            button7.Text = null;
            button8.Text = null;
            button9.Text = null;


            button1.BackColor=SystemColors.Control;
            button2.BackColor = SystemColors.Control;
            button3.BackColor = SystemColors.Control;
            button4.BackColor = SystemColors.Control;
            button5.BackColor = SystemColors.Control;
            button6.BackColor = SystemColors.Control;
            button7.BackColor = SystemColors.Control;
            button8.BackColor = SystemColors.Control;
            button9.BackColor = SystemColors.Control;


            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;
            button7.Enabled = true;
            button8.Enabled = true;
            button9.Enabled=true;

            turn = true;

        }
        public void buttons_Click(object sender,EventArgs e)
        {
            Button select = (Button)sender;
          select.BackColor = Color.LightGreen;
            turncount++;
            if (turn)
            {
                select.Text = "X";
                turn = false;
               
            }
            else
            {
                select.Text = "O";
                turn = true;

            }


                select.Enabled = false;
            if (button1.Text == "X" && button2.Text=="X" && button3.Text=="X") {
                MessageBox.Show("The Winner is player1");
                label3.Text = (int.Parse(label3.Text) + 1).ToString();

            }
            else if(button4.Text == "X" && button5.Text == "X" && button6.Text == "X")
            {
                MessageBox.Show("The Winner is player1");
                label3.Text = (int.Parse(label3.Text) + 1).ToString();

            }
            else if(button7.Text == "X" && button8.Text == "X" && button9.Text == "X")
            {
                MessageBox.Show("The Winner is player1");
                label3.Text = (int.Parse(label3.Text) + 1).ToString();

            }
            else if (button1.Text == "X" && button5.Text == "X" && button9.Text == "X")
            {
                MessageBox.Show("The Winner is player1");
                label3.Text = (int.Parse(label3.Text) + 1).ToString();

            }
            else if (button3.Text == "X" && button5.Text == "X" && button7.Text == "X")
            {
                MessageBox.Show("The Winner is player1");
                label3.Text = (int.Parse(label3.Text) + 1).ToString();

            }
            else if (button1.Text == "X" && button4.Text == "X" && button7.Text == "X")
            {
                MessageBox.Show("The Winner is player1");
                label3.Text = (int.Parse(label3.Text) + 1).ToString();

            }
            else if (button2.Text == "X" && button5.Text == "X" && button8.Text == "X")
            {
                MessageBox.Show("The Winner is player1");
                label3.Text = (int.Parse(label3.Text) + 1).ToString();

            }
            else if (button3.Text == "X" && button6.Text == "X" && button9.Text == "X")
            {
                MessageBox.Show("The Winner is player1");
                label3.Text = (int.Parse(label3.Text) + 1).ToString();
            }



            if (button1.Text == "O" && button2.Text == "O" && button3.Text == "O")
            {
                MessageBox.Show("The Winner is player2");
                label4.Text = (int.Parse(label4.Text) + 1).ToString();
            }
            else if (button4.Text == "O" && button5.Text == "O" && button6.Text == "O")
            {
                MessageBox.Show("The Winner is player2");
                label4.Text = (int.Parse(label4.Text) + 1).ToString();
            }
            else if (button7.Text == "O" && button8.Text == "O" && button9.Text == "O")
            {
                MessageBox.Show("The Winner is player2");
                label4.Text = (int.Parse(label4.Text) + 1).ToString();
            }
            else if (button1.Text == "O" && button5.Text == "O" && button9.Text == "O")
            {
                MessageBox.Show("The Winner is player2");
                label4.Text = (int.Parse(label4.Text) + 1).ToString();
            }
            else if (button3.Text == "O" && button5.Text == "O" && button7.Text == "O")
            {
                MessageBox.Show("The Winner is player2");
                label4.Text = (int.Parse(label4.Text) + 1).ToString();
            }
            else if (button1.Text == "O" && button4.Text == "O" && button7.Text == "O")
            {
                MessageBox.Show("The Winner is player2");
                label4.Text = (int.Parse(label4.Text) + 1).ToString();
            }
            else if (button2.Text == "O" && button5.Text == "O" && button8.Text == "O")
            {
                MessageBox.Show("The Winner is player2");
                label4.Text = (int.Parse(label4.Text) + 1).ToString();
            }
            else if (button3.Text == "O" && button6.Text == "O" && button9.Text == "O")
            {
                MessageBox.Show("The Winner is player2");
             label4.Text = (int.Parse(label4.Text)+1).ToString();
            }
            

        
           
           
            
            

           
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            Button reset = (Button)sender;
            resetgame();
            
        }

        private void button11_Click(object sender, EventArgs e)
        {
            label3.Text = "0";
            label4.Text = "0";
        }
       
       
    }
}
